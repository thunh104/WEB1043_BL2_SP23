// ============BÀI 1================
let a=prompt("Nhập vào giá trị a: ");
let b=prompt("Nhập vào giá trị b: ");
let c=Math.sqrt(Math.pow(a,2)+Math.pow(b,2));
console.log(c);
// ===========BÀI 2=================
let m2 = prompt("Nhập số m2: ");
let sao = m2 / 360;
let hecta = m2 / 3600;
let mau = m2 / 3600;
document.write("Số sào là: "+sao);
document.write("Số hecta là: "+hecta);
document.write("Số mẫu là: "+mau);


// ===========BÀI 3=================
let canNang = prompt("Nhập vào cân nặng của bạn: ");
console.log("Cân nặng"+canNang);
let chieuCao = prompt("Nhập vào chiều cao của bạn: ");
console.log("chiều cao"+chieuCao);
let BMI = (canNang)/(chieuCao * chieuCao);
console.log("Chỉ số BMI"+BMI);
if(BMI<18.5){
    document.write("Thiếu cân "+BMI);
}
else if(BMI >=18.5 && BMI<24.999){
    document.write("Bình thường"+BMI);
}
else if(BMI>=25 && BMI<29){
    document.write("Thừa cân"+BMI);
}
else{
    document.write("Béo phì"+BMI);
}
// //==============BÀI 4===============
const theList=['Lauren', 'Kevin', true,35,null,undefined,['one', 'two']];
console.log(theList);
console.log(theList.length);

// Xóa phần tử đầu tiên và cuối cùng
theList.pop();
console.log(theList);

theList.shift();
console.log(theList);

// Thêm FIRST vào đầu mảng
theList.unshift('FIRST');
console.log(theList);

//Thêm 'hello world' vào vị trí thứ 4 của mảng
theList.splice(3,0,"hello world");
console.log(theList);

//Thêm 'middle' vào vị trí thứ 3 của mảng
theList.splice(2,0,"middle");
console.log(theList);

// Thêm 'LAST' vào cuối mảng
theList.push("LAST");
console.log(theList);

// //================BÀI 5==============
var x = 10 + Math.round(5 * Math.random());
console.log('số trúng thưởng của bạn '+x);

var a = prompt("số nhập vào: ");
console.log('Số bạn chọn: '+a);
if(a==x){
    console.log("Chúc mừng, bạn đã đoán đúng");
}
else if(a>x){
    console.log("Giá trị của bạn lớn hơn số bí mật");
}
else{
    console.log("Giá trị của bạn nhỏ hơn số bí mật");
}
