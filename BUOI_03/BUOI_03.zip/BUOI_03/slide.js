let num=6.678;
let kq1=num.toFixed(10);
console.log(kq1);
console.log(typeof(kq1));
let tong=kq1+8;
console.log(tong);

//=====================MẢNG
let arr1= new Array(5,6,9); //Khai báo
console.log(arr1); //Xuất ra toàn bộ các phần tử
console.log(arr1[2]); //xuất ra phần tử của mảng, bắt đầu đếm từ 0
let arr2=['Hà','Hoa','Huệ'];
console.log(arr2);
//Ghi đè vào arr1
arr1[0]=10;
console.log(arr1);
// Lấy độ dài của mảng:length
console.log(arr1.length);
//Ghi đè vào mảng arr2
arr2[3]="Lan";
console.log(arr2);
// Thêm 1 phần tử vào cuối mảng
arr2.push("Phong");
console.log(arr2);
//sau vị trí số 2, xóa đi 2 phần tử và thêm 1 phần tử vào
arr2.splice(2,2,"Hùng"); 
console.log(arr2);
// Thêm Vương vào sau vị trí số 3 và không xóa gì 
arr2.splice(3,0,"Vương");
console.log(arr2);
//Thêm 3 phần tử vào sau vị trí 1
arr2.splice(1,0,"A","B","C");
console.log(arr2);
//Nối 2 mảng arr1 với arr2
let kq2=arr1.concat(arr2);
console.log(kq2);
// Xóa ở cuối mảng
kq2.pop();
console.log(kq2);
// xóa y phần tử từ sau phần tử x
kq2.splice(2,3);
console.log(kq2);
// Tìm vị trí của một phần tử trong mảng
//Nếu tìm thấy sẽ ra index của vị trí cần tìm, nếu kh tìm thấy sẽ ra -1
kq2.push("Hoa");
console.log(kq2);
//Tìm vị trí đầu tiên của Hoa
let vt=kq2.indexOf("Hoa");
console.log(vt);
//Tìm vị trí cuối cùng của Hoa
let lastvt=kq2.lastIndexOf("Hoa");
console.log(lastvt);
// Biến chuỗi thành mảng
let str="Thu Trang xinh đẹp";
let result=str.split(" ");
console.log(result);
// CHuyển mảng thành chuỗi
let arr=['a','b','c'];
let kq=arr.join()
console.log(kq);
console.log(typeof(kq));
//================LÀM TRÒN
let x=4.5689;
let y=5.341;
console.log(Math.trunc(x)); 
