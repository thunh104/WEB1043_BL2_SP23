// Câu lệnh rẽ nhánh IF
// var x =prompt("Nhập x=");
// if(x==1){
//     alert("Số 1");
// }
// else{
//     alert("Không phải 1");
// }
// // Toán tử 3 ngôi
//  alert((x==1)?"Số 1":"Không phải 1");
// // if lồng 
// let diem = prompt("Nhập điểm: ");
// if(diem<5){
//     document.write("Trượt");
// }
// else if(diem<7){
//     document.write("Đỗ trung bình");
// }
// else if(diem<8){
//     document.write("Đỗ khá");
// }
// else{
//     document.write("Đỗ giỏi");
// }
// =============SWITCH CASE===========
// let thu = prompt("Nhập thứ: ");
// switch(thu){
//     case "2":
//         document.write("Thứ hai");
//         break;
//     case "3":
//         document.write("Thứ ba");
//         break;
//     case "4":
//         document.write("Thứ tư");
//         break;  
//     case "5":
//         document.write("Thứ năm");
//         break;
//     case "6":
//         document.write("Thứ sáu");
//         break;
//     case "7":
//         document.write("Thứ bảy");
//         break;
//     default:
//         alert("Bạn cần nhập số từ 2-7");
//         break;
// }
// =============== VÒNG LẶP FOR========
// let tong = 0;
// for( let i=4; i<=13; i++){
//     tong= tong +i;
// }
// document.write(`Tổng là: ${tong}`);
// ============== VÒNG LẶP WHILE=======
// let tong = 0;
// let i=4;
// while(i<=13){
//     tong = tong +i;
//     i++;
// }
// document.write(` Tổng là: ${tong}`);
// ================ DUYỆT MẢNG =============
let arr=['Hà','HẰng','Hoa', 'Hà',"Hải","An",'Hà'];
dem = 0;
for(let i=0; i<arr.length;i++){
    if(arr[i]=="Hà") dem=dem+1;
}
document.write(` Có ${dem} phần tử Hà trong mảng`);