// let weight = prompt("Nhập trọng lượng cơ thể: ");
// let height = prompt("Nhập chiều cao: ");
// let BMI = weight/(height*height);
// if(BMI<18.5){
//     document.write("Thiếu cân"+BMI);
// }
// else if(18.5 <=BMI && BMI<=24.99){
//     document.write("Bình thường"+BMI);
// }
// else if(25<=BMI && BMI<=29.99){
//     document.write("Thừa cân"+BMI);
// }
// else{
//     document.write("Béo phì"+BMI);
// }

let m2 = Number(prompt("Nhập m2 đất:"));
let ha = 0;
let sao = 0;
ha = m2/3600;
sao = m2%360;
if(ha>0){
    document.write(ha+" mau "+sao+" sao");
}
else{
    document.write(sao+" sao");
}