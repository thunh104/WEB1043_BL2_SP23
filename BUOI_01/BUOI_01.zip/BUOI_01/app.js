var x = prompt("Nhập n: ");
document.write(x);
// NHập dữ liệu
// Xuất dữ liệu ra màn hình
