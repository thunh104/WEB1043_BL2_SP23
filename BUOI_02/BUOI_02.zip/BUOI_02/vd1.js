// =================KHAI BÁO VÀ SỬ DỤNG BIẾN
var x=100;
console.log(x);
x=300;
console.log(x);
x="Thu Trang";
console.log(x);
const path="C:/Baitap";
console.log(path);
// path="D:/Baitap";
console.log(n);
var n=2;

// ==================KHAI BÁO VÀ SỬ DỤNG CHUỖI
// sử dụng dấu + để nối chuỗi
let subject="HTML & CSS"
let str1="Thu Trang đang học "+ subject+ " Tại phòng L404";
console.log(str1);
let str2='Thu Trang đang học '+ subject+ " Tại phòng D402";
console.log(str2);
let str3= `Thu Trang đang học $(subject) Tại phòng D403`;
console.log(str3);
console.log(subject.length) //length: tính độ dài của chuỗi
console.log(subject.substring(0,4)) //substring: trích kí tự từ trong chuỗi, đánh bắt đầu từ 0
console.log(subject.substring(7,10))

// NỐi 2 chuỗi thành 1 chuỗi: concat
let name="Thu Trang"
let job="Sinh viên"
let noi=name.concat(": ", job)
console.log(noi)

console.log(name.toUpperCase()) // Chuyển chuỗi thành in hoa
console.log(name.toLowerCase()) // Chuyển chuỗi thành chữ thường
 
//==================NUMBER
let num=18.364845
console.log(num)
console.log(typeof(num))
console.log(num+10)

let ten="Thu Trang"
console.log(isNaN(ten))
console.log(isNaN(num))

let result=num.toFixed()
console.log(result)
console.log(typeof(result))
let tong=result+10
console.log(tong)